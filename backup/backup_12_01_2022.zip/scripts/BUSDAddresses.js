
module.exports = {
  addresses: {
    "testnet": "0x862BcFA4305DD0ecF1a82796fFc9c3627E0b592a",
    "mainnet": "", // Careful
  }
};