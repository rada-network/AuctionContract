
module.exports = {
  addresses: {
    "testnet": "0x04765e334e19adFDbA244B66C4BB88a324110d57",
    "mainnet": "", // Careful
  }
};