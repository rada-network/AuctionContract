
module.exports = {
  addresses: {
    "testnet": "0xF567103C1F846217C58995c205662F3ECF22302B",
    "mainnet": ""
  }
};
