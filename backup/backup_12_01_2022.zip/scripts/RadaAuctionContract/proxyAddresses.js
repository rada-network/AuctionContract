
module.exports = {
  addresses: {
    "testnet": "0x63B70bAD9a1958eF743EeF22086637FaD92f3555",
    "mainnet": ""
  }
};