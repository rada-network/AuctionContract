
module.exports = {
  addresses: {
    "testnet": "0x8cE3514596bfe2E15c1e38c3446DCca17F2317df",
    "mainnet": ""
  }
};