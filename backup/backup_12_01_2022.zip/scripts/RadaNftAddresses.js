
module.exports = {
  addresses: {
    "testnet": "0x6e1aa924A1882B7C1122290E11A9fE94F63Af52d",
    "mainnet": "", // Careful
  }
};