
module.exports = {
  addresses: {
    "polygonMumbai": "0x7a789f5620408a44219e63a5b037f12a5f36196b",
    "polygon": ""
  }
};
